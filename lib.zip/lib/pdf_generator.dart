import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';
import 'database_helper.dart';

class PdfGenerator {

  static Future<void> generateAndPrint(int invoiceId) async {
    final invoices = await DatabaseHelper.instance.getAllInvoices();
    final invoice = invoices.firstWhere((i) => i['id'] == invoiceId, orElse: () => {});

    if (invoice.isEmpty) return;

    final items = await DatabaseHelper.instance.getInvoiceItems(invoiceId);
    final user = await DatabaseHelper.instance.getUser();

    String shopName = user?['shop_name'] ?? "MY SHOP";
    String shopPhone = user?['phone'] ?? "";
    String shopAddress = user?['address'] ?? "";
    String custName = invoice['customer_name'] ?? "Unknown";

    // Data Fields
    double grandTotal = invoice['total_amount'];
    double discount = invoice['discount'] ?? 0.0;
    double paidAmount = invoice['paid_amount'];
    double balance = invoice['balance_due'];

    // Recalculate Subtotal
    double subTotal = grandTotal + discount;

    DateTime date = DateTime.parse(invoice['date']);

    final font = await PdfGoogleFonts.notoSansDevanagariRegular();
    final pdf = pw.Document();

    pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.roll80,
        margin: const pw.EdgeInsets.all(10),
        build: (pw.Context context) {
          // CHANGED: Symbol set to 'Rs. '
          String fmt(double amount) => NumberFormat.currency(symbol: 'Rs. ', locale: 'en_IN', decimalDigits: 2).format(amount);

          return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                pw.Text(shopName.toUpperCase(), style: pw.TextStyle(font: font, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                if (shopAddress.isNotEmpty) pw.Text(shopAddress, textAlign: pw.TextAlign.center, style: pw.TextStyle(font: font, fontSize: 10)),
                if (shopPhone.isNotEmpty) pw.Text("Tel: $shopPhone", style: pw.TextStyle(font: font, fontSize: 10)),
                pw.SizedBox(height: 10),
                pw.Divider(borderStyle: pw.BorderStyle.dashed),

                pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                  pw.Text("Inv #: $invoiceId", style: pw.TextStyle(font: font, fontSize: 10)),
                  pw.Text(DateFormat('dd/MM/yy HH:mm').format(date), style: pw.TextStyle(font: font, fontSize: 10)),
                ]),
                pw.Align(alignment: pw.Alignment.centerLeft, child: pw.Text("Cust: $custName", style: pw.TextStyle(font: font, fontSize: 10))),

                pw.Divider(borderStyle: pw.BorderStyle.dashed),

                pw.Table(
                    columnWidths: {0: const pw.FlexColumnWidth(3), 1: const pw.FlexColumnWidth(1), 2: const pw.FlexColumnWidth(2)},
                    children: [
                      pw.TableRow(children: [
                        pw.Text("Item", style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold, fontSize: 10)),
                        pw.Text("Qty", textAlign: pw.TextAlign.center, style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold, fontSize: 10)),
                        pw.Text("Total", textAlign: pw.TextAlign.right, style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold, fontSize: 10)),
                      ]),
                      pw.TableRow(children: [pw.SizedBox(height: 5), pw.SizedBox(height: 5), pw.SizedBox(height: 5)]),
                      ...items.map((item) => pw.TableRow(children: [
                        pw.Text(item['product_name'], style: pw.TextStyle(font: font, fontSize: 10)),
                        pw.Text("${item['quantity']}", textAlign: pw.TextAlign.center, style: pw.TextStyle(font: font, fontSize: 10)),
                        pw.Text((item['line_total'] as double).toStringAsFixed(2), textAlign: pw.TextAlign.right, style: pw.TextStyle(font: font, fontSize: 10)),
                      ]))
                    ]
                ),

                pw.SizedBox(height: 10),
                pw.Divider(borderStyle: pw.BorderStyle.dashed),

                // Subtotal & Discount Logic
                if (discount > 0) ...[
                  pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                    pw.Text("Subtotal:", style: pw.TextStyle(font: font, fontSize: 10)),
                    pw.Text(fmt(subTotal), style: pw.TextStyle(font: font, fontSize: 10)),
                  ]),
                  pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                    pw.Text("Discount:", style: pw.TextStyle(font: font, fontSize: 10)),
                    pw.Text("- ${fmt(discount)}", style: pw.TextStyle(font: font, fontSize: 10)),
                  ]),
                  pw.Divider(borderStyle: pw.BorderStyle.dotted),
                ],

                pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                  pw.Text("TOTAL", style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold, fontSize: 14)),
                  pw.Text(fmt(grandTotal), style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold, fontSize: 14)),
                ]),

                pw.SizedBox(height: 5),

                if (balance <= 0) ...[
                  pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                    pw.Text("Status:", style: pw.TextStyle(font: font, fontSize: 10)),
                    pw.Text("PAID", style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold)),
                  ]),
                ] else ...[
                  pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                    pw.Text("Paid:", style: pw.TextStyle(font: font, fontSize: 10)),
                    pw.Text(fmt(paidAmount), style: pw.TextStyle(font: font, fontSize: 10)),
                  ]),
                  pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                    pw.Text("Due:", style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold)),
                    pw.Text(fmt(balance), style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold)),
                  ]),
                ],

                pw.SizedBox(height: 20),
                pw.Text("THANK YOU!", style: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold)),
              ]
          );
        }
    ));

    await Printing.layoutPdf(onLayout: (format) async => pdf.save());
  }
}