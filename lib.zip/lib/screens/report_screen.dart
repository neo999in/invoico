import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database_helper.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  bool _isLoading = true;
  Map<String, dynamic> _data = {};
  DateTime _selectedMonth = DateTime.now();

  @override
  void initState() {
    super.initState();
    _loadReport();
  }

  void _loadReport() async {
    setState(() => _isLoading = true);
    final data = await DatabaseHelper.instance.getAdvancedReportData(_selectedMonth);

    if (mounted) {
      setState(() {
        _data = data;
        _isLoading = false;
      });
    }
  }

  void _changeMonth(int offset) {
    setState(() {
      _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + offset, 1);
    });
    _loadReport();
  }

  double _parse(dynamic val) {
    if (val == null) return 0.0;
    if (val is num) return val.toDouble();
    return double.tryParse(val.toString()) ?? 0.0;
  }

  String fmt(dynamic val) => "₹${_parse(val).toStringAsFixed(0)}";

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final Color primary = Theme.of(context).colorScheme.primary;

    // --- Data Extraction ---
    final kpis = _data['monthly_kpis'] ?? {};
    final profitTax = _data['monthly_profit_tax'] ?? {};

    final totalRevenue = _parse(kpis['total_revenue']);
    final totalOrders = _parse(kpis['total_orders']);
    final totalDiscount = _parse(kpis['total_discount']);

    final totalProfit = _parse(profitTax['total_profit']);
    final totalGst = _parse(profitTax['total_gst']);

    final aov = totalOrders > 0 ? (totalRevenue / totalOrders) : 0.0;
    final profitMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0.0;

    final gstSlabs = List<Map<String, dynamic>>.from(_data['gst_slabs'] ?? []);
    final mostSelling = _data['most_selling'];
    final mostProfitable = _data['most_profitable'];
    final catStats = List<Map<String, dynamic>>.from(_data['category_stats'] ?? []);
    final dailyStats = List<Map<String, dynamic>>.from(_data['daily_stats'] ?? []);
    final topCustomers = List<Map<String, dynamic>>.from(_data['top_customers'] ?? []);
    final invVal = _data['inv_value'] ?? {};
    final deadStock = List<Map<String, dynamic>>.from(_data['dead_stock'] ?? []);
    final expenses = List<Map<String, dynamic>>.from(_data['expenses'] ?? []);
    final cashFlow = _data['cash_flow'] ?? {'in': 0, 'out': 0};

    bool noActivity = totalOrders == 0;
    DateTime refDate = (_selectedMonth.year == DateTime.now().year && _selectedMonth.month == DateTime.now().month)
        ? DateTime.now() : DateTime(_selectedMonth.year, _selectedMonth.month + 1, 0);

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Business Analytics", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Month Selector
            Container(
              color: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Reporting Period", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                  Container(
                    decoration: BoxDecoration(color: primary.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      children: [
                        IconButton(icon: const Icon(Icons.chevron_left, size: 20), color: primary, onPressed: () => _changeMonth(-1)),
                        Text(DateFormat('MMM yyyy').format(_selectedMonth), style: TextStyle(fontWeight: FontWeight.bold, color: primary)),
                        IconButton(
                            icon: const Icon(Icons.chevron_right, size: 20), color: primary,
                            onPressed: (_selectedMonth.year == DateTime.now().year && _selectedMonth.month == DateTime.now().month) ? null : () => _changeMonth(1)
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),

            if (noActivity)
              Padding(
                padding: const EdgeInsets.only(top: 80.0),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.insights, size: 80, color: Colors.grey.shade300),
                      const SizedBox(height: 16),
                      Text("No activity in ${DateFormat('MMMM yyyy').format(_selectedMonth)}", style: const TextStyle(color: Colors.grey, fontSize: 16)),
                    ],
                  ),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // --- 1. TOP KPIs GRID ---
                    _buildSectionTitle("Monthly Overview"),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        mainAxisExtent: 75,
                      ),
                      itemCount: 6,
                      itemBuilder: (context, index) {
                        final cards = [
                          _buildKpiCard("Total Revenue", fmt(totalRevenue), Icons.account_balance_wallet, Colors.blue.shade700),
                          _buildKpiCard("Net Profit", fmt(totalProfit), Icons.trending_up, Colors.green.shade600),
                          _buildKpiCard("Profit Margin", "${profitMargin.toStringAsFixed(1)}%", Icons.pie_chart, Colors.teal.shade600),
                          _buildKpiCard("Total Orders", totalOrders.toStringAsFixed(0), Icons.receipt_long, Colors.purple.shade500),
                          _buildKpiCard("Avg Order Value", fmt(aov), Icons.shopping_bag, Colors.orange.shade600),
                          _buildKpiCard("Discounts Given", fmt(totalDiscount), Icons.loyalty, Colors.red.shade400),
                        ];
                        return cards[index];
                      },
                    ),

                    // --- 2. DEBT & TAXES ---
                    _buildSectionTitle("Finance Health & Taxes"),
                    _buildDebtRatioBar(_parse(kpis['total_paid']), _parse(kpis['total_due'])),
                    const SizedBox(height: 12),

                    // NEW: GST Compliance Table
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text("GST Collected", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                  Text("Slab-wise breakdown for tax filing.", style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                                ],
                              ),
                              Text(fmt(totalGst), style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, fontSize: 18)),
                            ],
                          ),
                          if (gstSlabs.isNotEmpty) ...[
                            const SizedBox(height: 16),
                            Container(
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade200),
                                  borderRadius: BorderRadius.circular(8)
                              ),
                              child: Table(
                                columnWidths: const {
                                  0: FlexColumnWidth(1),
                                  1: FlexColumnWidth(2),
                                  2: FlexColumnWidth(2),
                                },
                                children: [
                                  TableRow(
                                      decoration: BoxDecoration(color: Colors.grey.shade50),
                                      children: [
                                        _tableHeader("Slab"),
                                        _tableHeader("Sales Amount", align: TextAlign.right),
                                        _tableHeader("Tax Amount", align: TextAlign.right),
                                      ]
                                  ),
                                  ...gstSlabs.map((s) => TableRow(
                                      decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey.shade200))),
                                      children: [
                                        _tableCell("${_parse(s['slab']).toInt()}%", bold: true),
                                        _tableCell(fmt(s['total_sales']), align: TextAlign.right),
                                        _tableCell(fmt(s['tax_collected']), align: TextAlign.right, color: Colors.redAccent),
                                      ]
                                  ))
                                ],
                              ),
                            )
                          ]
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // --- 3. TRENDS ---
                    _buildSectionTitle("Sales Trends (Last 7 Days)"),
                    _buildCustomBarChart(dailyStats, refDate),
                    const SizedBox(height: 24),

                    // --- 4. TOP CUSTOMERS ---
                    if (topCustomers.isNotEmpty) ...[
                      _buildSectionTitle("Top Loyal Customers"),
                      Card(
                        color: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: topCustomers.length,
                          separatorBuilder: (_,__) => const Divider(height: 1, indent: 60),
                          itemBuilder: (ctx, i) {
                            final c = topCustomers[i];
                            return ListTile(
                              leading: CircleAvatar(backgroundColor: primary.withOpacity(0.1), child: Text("${i+1}", style: TextStyle(color: primary, fontWeight: FontWeight.bold))),
                              title: Text(c['customer_name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Text("${c['orders']} Orders"),
                              trailing: Text(fmt(c['spent']), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.green)),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],

                    // --- 5. PRODUCT & CATEGORY PERFORMANCE ---
                    _buildSectionTitle("Product Performance"),
                    Row(
                      children: [
                        _buildHighlightCard("Most Sold", mostSelling?['product_name'] ?? "N/A", "${mostSelling?['qty'] ?? 0} units", Colors.blue),
                        const SizedBox(width: 12),
                        _buildHighlightCard("Top Earner", mostProfitable?['product_name'] ?? "N/A", fmt(mostProfitable?['profit']), Colors.green),
                      ],
                    ),
                    const SizedBox(height: 12),

                    if (catStats.isNotEmpty) ...[
                      Card(
                        color: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: catStats.length,
                          separatorBuilder: (_,__) => const Divider(height: 1),
                          itemBuilder: (ctx, i) {
                            final cat = catStats[i];
                            double sales = _parse(cat['sales']);
                            double profit = _parse(cat['profit']);
                            double gst = _parse(cat['gst_collected']);
                            Color textColor = sales > 0 ? Colors.black87 : Colors.grey.shade400;

                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("${cat['category'] ?? 'Other'} (${_parse(cat['product_count']).toInt()} products)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: textColor)),
                                        const SizedBox(height: 4),
                                        Text("Sales: ${fmt(sales)} (${_parse(cat['total_qty_sold']).toInt()} units)", style: TextStyle(color: sales > 0 ? Colors.grey.shade700 : Colors.grey.shade400, fontSize: 12)),
                                      ],
                                    ),
                                  ),
                                  Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text("Profit: ${fmt(profit)}", style: TextStyle(fontWeight: FontWeight.bold, color: sales == 0 ? Colors.grey.shade400 : (profit >= 0 ? Colors.green : Colors.red), fontSize: 13)),
                                        const SizedBox(height: 2),
                                        Text("GST: ${fmt(gst)}", style: TextStyle(fontWeight: FontWeight.bold, color: sales == 0 ? Colors.grey.shade300 : Colors.deepOrange.shade400, fontSize: 11)),
                                      ]
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],

                    // --- 6. CASH FLOW & EXPENSES ---
                    _buildSectionTitle("Cash Flow Summary"),
                    Row(
                        children: [
                          _buildCard("Money In", fmt(cashFlow['in']), Icons.south_west, Colors.teal),
                          const SizedBox(width: 12),
                          _buildCard("Money Out", fmt(cashFlow['out']), Icons.north_east, Colors.red),
                        ]
                    ),
                    const SizedBox(height: 16),

                    if (expenses.isNotEmpty) ...[
                      _buildExpenseBar(expenses),
                      const SizedBox(height: 24),
                    ],

                    // --- 7. INVENTORY VALUATION & DEAD STOCK ---
                    _buildSectionTitle("Inventory valuation"),
                    Row(
                        children: [
                          _buildCard("Capital invested", fmt(invVal['capital']), Icons.inventory_2, Colors.indigo),
                          const SizedBox(width: 12),
                          _buildCard("Potential revenue", fmt(invVal['revenue']), Icons.attach_money, Colors.green),
                        ]
                    ),
                    const SizedBox(height: 16),

                    if (deadStock.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.orange.shade200)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                                const SizedBox(width: 8),
                                const Text("Dead Stock", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
                                const Spacer(),
                                Text("${deadStock.length} items", style: const TextStyle(color: Colors.orange, fontSize: 12, fontWeight: FontWeight.bold))
                              ],
                            ),
                            const SizedBox(height: 4),
                            const Text("No sales in the last 30 days.", style: TextStyle(color: Colors.deepOrange, fontSize: 12)),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8, runSpacing: 8,
                              children: deadStock.map((s) => Chip(
                                label: Text("${s['name']} (${s['stock']})", style: const TextStyle(fontSize: 11, color: Colors.deepOrange)),
                                backgroundColor: Colors.white,
                                side: BorderSide.none,
                                padding: EdgeInsets.zero,
                              )).toList(),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 40),
                    ] else ...[
                      const SizedBox(height: 24),
                    ]
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ==========================================
  // WIDGET HELPERS
  // ==========================================

  Widget _tableHeader(String text, {TextAlign align = TextAlign.left}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(text, textAlign: align, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey.shade600, fontSize: 12)),
    );
  }

  Widget _tableCell(String text, {TextAlign align = TextAlign.left, bool bold = false, Color color = Colors.black87}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(text, textAlign: align, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, color: color, fontSize: 12)),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Colors.black87)),
    );
  }

  Widget _buildKpiCard(String title, String val, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.grey.shade200, blurRadius: 8, offset: const Offset(0, 2))]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, size: 14, color: color),
              const SizedBox(width: 6),
              Expanded(child: Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis)),
            ],
          ),
          const SizedBox(height: 6),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900), maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildHighlightCard(String title, String val, String sub, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: color.withOpacity(0.05), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(0.2))),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 8),
            Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(sub, style: TextStyle(color: color.withOpacity(0.8), fontWeight: FontWeight.bold, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(String title, String val, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(height: 8),
              Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
            ]
        ),
      ),
    );
  }

  Widget _buildDebtRatioBar(double paid, double due) {
    double total = paid + due;
    if (total == 0) return const SizedBox();

    int paidFlex = (paid / total * 100).toInt();
    int dueFlex = 100 - paidFlex;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Collected: ${fmt(paid)} ($paidFlex%)", style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12)),
              Text("Unpaid: ${fmt(due)} ($dueFlex%)", style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 12, width: double.infinity,
            decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(10)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Row(
                children: [
                  if (paidFlex > 0) Expanded(flex: paidFlex, child: Container(color: Colors.green)),
                  if (dueFlex > 0) Expanded(flex: dueFlex, child: Container(color: Colors.red)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomBarChart(List<Map<String, dynamic>> dailyStats, DateTime refDate) {
    List<Map<String, dynamic>> chartData = [];
    double maxVal = 1;

    for (int i = 6; i >= 0; i--) {
      DateTime d = refDate.subtract(Duration(days: i));
      String dStr = DateFormat('yyyy-MM-dd').format(d);
      var match = dailyStats.firstWhere((e) => e['date_str'] == dStr, orElse: () => {'sales': 0.0, 'profit': 0.0});

      double sales = _parse(match['sales']);
      double profit = _parse(match['profit']);

      if (sales > maxVal) maxVal = sales;
      if (profit > maxVal) maxVal = profit;

      chartData.add({'day': DateFormat('E').format(d), 'sales': sales, 'profit': profit});
    }

    return Container(
      height: 180,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: chartData.map((d) {
          double sHeight = (d['sales'] / maxVal) * 120;
          double pHeight = (d['profit'] / maxVal) * 120;

          if (sHeight < 2 && d['sales'] > 0) sHeight = 5;
          if (pHeight < 2 && d['profit'] > 0) pHeight = 5;

          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(width: 10, height: sHeight, decoration: BoxDecoration(color: Colors.blue.shade400, borderRadius: const BorderRadius.vertical(top: Radius.circular(4)))),
                  const SizedBox(width: 2),
                  Container(width: 10, height: pHeight, decoration: BoxDecoration(color: Colors.green.shade400, borderRadius: const BorderRadius.vertical(top: Radius.circular(4)))),
                ],
              ),
              const SizedBox(height: 8),
              Text(d['day'].toString(), style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildExpenseBar(List<Map<String, dynamic>> expenses) {
    final colors = [Colors.red, Colors.orange, Colors.purple, Colors.blue, Colors.teal, Colors.brown];
    double totalExp = expenses.fold(0.0, (sum, e) => sum + _parse(e['total']));

    if (totalExp == 0) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Expense Breakdown", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Container(
            height: 12, width: double.infinity,
            decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(10)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Row(
                children: expenses.asMap().entries.map((e) {
                  int flex = ((_parse(e.value['total']) / totalExp) * 100).toInt();
                  if (flex == 0) flex = 1;
                  return Expanded(flex: flex, child: Container(color: colors[e.key % colors.length]));
                }).toList(),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12, runSpacing: 8,
            children: expenses.asMap().entries.map((e) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 10, height: 10, decoration: BoxDecoration(color: colors[e.key % colors.length], shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Text("${e.value['title']} (${fmt(e.value['total'])})", style: const TextStyle(fontSize: 12)),
                ],
              );
            }).toList(),
          )
        ],
      ),
    );
  }
}