import 'package:flutter/material.dart';
import '../database_helper.dart';

class CustomerScreen extends StatefulWidget {
  const CustomerScreen({super.key});
  @override
  State<CustomerScreen> createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  List<Map<String, dynamic>> customers = [];
  List<Map<String, dynamic>> filteredCustomers = [];
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _refresh();
    _searchCtrl.addListener(_filter);
  }

  void _refresh() async {
    final d = await DatabaseHelper.instance.getCustomers();
    setState(() { customers = d; filteredCustomers = d; });
    _filter();
  }

  void _filter() {
    String query = _searchCtrl.text.toLowerCase();
    setState(() {
      filteredCustomers = customers.where((c) => c['name'].toLowerCase().contains(query) || c['phone'].contains(query)).toList();
    });
  }

  void _showCustomerForm({Map<String, dynamic>? customer}) {
    final nameCtrl = TextEditingController(text: customer?['name']);
    final phoneCtrl = TextEditingController(text: customer?['phone']);
    final addrCtrl = TextEditingController(text: customer?['address']);
    bool isEditing = customer != null;

    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.fromLTRB(24, 24, 24, MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(isEditing ? "Edit Customer" : "Add New Customer", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: "Full Name", prefixIcon: Icon(Icons.person))),
          const SizedBox(height: 12),
          TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: "Phone Number", prefixIcon: Icon(Icons.phone)), keyboardType: TextInputType.phone, readOnly: isEditing, style: TextStyle(color: isEditing ? Colors.grey : Colors.black)),
          const SizedBox(height: 12),
          TextField(controller: addrCtrl, decoration: const InputDecoration(labelText: "Address", prefixIcon: Icon(Icons.location_on))),
          const SizedBox(height: 24),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () async {
            if (nameCtrl.text.isEmpty || phoneCtrl.text.isEmpty) return;
            try {
              final data = {'name': nameCtrl.text, 'phone': phoneCtrl.text, 'address': addrCtrl.text};
              isEditing ? await DatabaseHelper.instance.updateCustomer(data) : await DatabaseHelper.instance.addCustomer(data);
              if(mounted) Navigator.pop(context); _refresh();
            } catch (e) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Phone already exists!"))); }
          }, child: const Text("SAVE CUSTOMER")))
        ],
      ),
    ));
  }

  void _deleteCustomer(String phone) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text("Delete Customer?"),
      content: const Text("This removes the customer profile. Invoices will remain but unlinked."),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text("CANCEL")),
        TextButton(onPressed: () async { await DatabaseHelper.instance.deleteCustomer(phone); if(mounted) Navigator.pop(context); _refresh(); }, child: const Text("DELETE", style: TextStyle(color: Colors.red))),
      ],
    ));
  }

  void _showDetails(Map<String, dynamic> c) async {
    final inv = await DatabaseHelper.instance.getCustomerInvoices(c['phone']);
    if(!mounted) return;

    showModalBottomSheet(context: context, isScrollControlled: true, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))), builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6, maxChildSize: 0.9, expand: false,
        builder: (_, scrollCtrl) => Padding(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(radius: 24, backgroundColor: Colors.indigo.shade50, child: Text(c['name'][0].toUpperCase(), style: const TextStyle(fontSize: 24, color: Colors.indigo, fontWeight: FontWeight.bold))),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c['name'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Row(children: [const Icon(Icons.phone, size: 14, color: Colors.grey), const SizedBox(width: 4), Text(c['phone'], style: TextStyle(color: Colors.grey.shade700))]),
                const SizedBox(height: 4),
                Row(children: [const Icon(Icons.location_on, size: 14, color: Colors.grey), const SizedBox(width: 4), Expanded(child: Text(c['address'] ?? 'No Address', style: TextStyle(color: Colors.grey.shade700), maxLines: 1, overflow: TextOverflow.ellipsis))]),
              ])),
            ]),
            const SizedBox(height: 24),
            const Text("Purchase History", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.indigo)),
            const SizedBox(height: 12),
            Expanded(child: inv.isEmpty ? const Center(child: Text("No purchases yet", style: TextStyle(color: Colors.grey))) : ListView.separated(
                controller: scrollCtrl, itemCount: inv.length, separatorBuilder: (_,__) => const SizedBox(height: 8),
                itemBuilder: (context, x) => Card(
                  color: Colors.grey.shade50, elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  child: ListTile(
                    title: Text("Inv #${inv[x]['id']}", style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(inv[x]['date'].toString().substring(0, 10)),
                    trailing: Text("₹${inv[x]['total_amount']}", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 16)),
                  ),
                )
            ))
          ]),
        )
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Customers", style: TextStyle(fontWeight: FontWeight.bold))),
        floatingActionButton: FloatingActionButton(onPressed: () => _showCustomerForm(), child: const Icon(Icons.person_add)),
        body: Column(
          children: [
            Padding(padding: const EdgeInsets.all(16), child: TextField(controller: _searchCtrl, decoration: const InputDecoration(labelText: "Search Name or Phone", prefixIcon: Icon(Icons.search)))),
            Expanded(
              child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  separatorBuilder: (_,__) => const SizedBox(height: 10), itemCount: filteredCustomers.length,
                  itemBuilder: (ctx, i) {
                    final c = filteredCustomers[i];
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        leading: CircleAvatar(backgroundColor: Colors.indigo.shade50, child: Text(c['name'][0].toUpperCase(), style: const TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold))),
                        title: Text(c['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        subtitle: Text(c['phone'], style: TextStyle(color: Colors.grey.shade600)),
                        onTap: () => _showDetails(c),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(icon: const Icon(Icons.edit, size: 20, color: Colors.blue), onPressed: () => _showCustomerForm(customer: c)),
                            IconButton(icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red), onPressed: () => _deleteCustomer(c['phone'])),
                          ],
                        ),
                      ),
                    );
                  }
              ),
            ),
          ],
        )
    );
  }
}